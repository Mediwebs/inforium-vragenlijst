import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import ts from 'typescript';
const toModule=s=>'data:text/javascript;base64,'+Buffer.from(ts.transpileModule(s,{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText).toString('base64');
const intakeUrl=toModule(await readFile(new URL('../lib/intake.ts',import.meta.url),'utf8'));
const {generalIntakeDefinition}=await import(intakeUrl);
const savedSource=(await readFile(new URL('../lib/saved-intakes.ts',import.meta.url),'utf8')).replace("'./intake'",JSON.stringify(intakeUrl));
const {readSavedIntakes,writeSavedIntakes,parseIntakeFile,INTAKE_STORAGE_KEY}=await import(toModule(savedSource));
function storage(){const values=new Map();return {getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v)};}
test('multiple saved forms reload independently and update/delete without losing other forms',()=>{
 const s=storage();assert.deepEqual(readSavedIntakes(s),[]);
 const original=structuredClone(generalIntakeDefinition);const copy=structuredClone(original);copy.code='INF-SECOND-001';copy.title[0]='Tweede intake';copy.sections[0].fields[4].label[0]='Andere reden voor bezoek?';
 const a={id:'a',savedAt:'2026-10-11T11:00:00Z',definition:original},b={id:'b',savedAt:'2026-10-11T11:01:00Z',definition:copy};
 writeSavedIntakes(s,[a,b]);assert.deepEqual(readSavedIntakes(s),[a,b]);
 const loaded=readSavedIntakes(s);loaded[1].definition.title[0]='Bijgewerkt';writeSavedIntakes(s,loaded);assert.equal(readSavedIntakes(s)[0].definition.title[0],original.title[0]);
 writeSavedIntakes(s,[loaded[1]]);assert.equal(readSavedIntakes(s).length,1);assert.equal(readSavedIntakes(s)[0].definition.title[0],'Bijgewerkt');
});
test('JSON import/export retains branching and fixed numbers and discards unrelated patient data',()=>{
 const d=structuredClone(generalIntakeDefinition);d.code='INF-IMPORT-001';d.title[0]='Méér intake';d.sections[0].fields=d.sections[0].fields.filter(f=>f.id!=='email');
 const parsed=parseIntakeFile(JSON.stringify({...d,answers:{name:'Patient'},responses:[{answer:'Private'}]}));assert.deepEqual(parsed,d);assert.ok(!('answers' in parsed));assert.equal(parsed.sections[0].fields.find(f=>f.id==='phone').questionNumber,4);
});
test('bad imports/storage and blocked writes fail explicitly without overwriting stored data',()=>{
 for(const text of ['bad','{}',JSON.stringify({...generalIntakeDefinition,code:'bad code'})])assert.throws(()=>parseIntakeFile(text));
 const s=storage();s.setItem(INTAKE_STORAGE_KEY,'broken');assert.throws(()=>readSavedIntakes(s));assert.equal(s.getItem(INTAKE_STORAGE_KEY),'broken');
 assert.throws(()=>writeSavedIntakes({setItem(){throw new Error('quota');}},[]));
});
