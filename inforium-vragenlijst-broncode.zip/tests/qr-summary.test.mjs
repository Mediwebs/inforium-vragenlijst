import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import ts from 'typescript';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
const source=await readFile(new URL('../lib/qr-summary.ts',import.meta.url),'utf8');
const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const {makeQrSummary,qrByteLength,validateQrSummary}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
test('QR selection excludes omitted answers and preserves missing answers explicitly',()=>{
 const responses=[{questionId:'reason',question:'Waar komt u voor?',answer:'Oorpijn'},{questionId:'medication',question:'Medicijnen?',answer:'paracetamol'},{questionId:'operations',question:'Operaties?',answer:null}];
 const text=makeQrSummary('Korte vragenlijst',responses,['reason','operations']);
 assert.match(text,/Oorpijn/);assert.match(text,/Operaties\? Niet ingevuld/);assert.doesNotMatch(text,/paracetamol/);
});
test('byte limit counts Unicode correctly and never truncates answers',()=>{
 assert.equal(qrByteLength('é😀'),6);
 assert.equal(validateQrSummary('a'.repeat(800)),null);
 assert.ok(validateQrSummary('a'.repeat(801)));
 assert.ok(validateQrSummary('é'.repeat(401)));
 assert.ok(validateQrSummary('   '));
});
test('QR roundtrip preserves exact UTF-8 text at the demo limit',()=>{
 const prefix='Inforium DEMO\nMedicijnen: café 😀\n';
 const text=prefix+'a'.repeat(800-qrByteLength(prefix));
 const qr=QRCode.create([{data:new TextEncoder().encode(text),mode:'byte'}],{errorCorrectionLevel:'M'});
 const scale=6,margin=4,width=(qr.modules.size+margin*2)*scale;
 const pixels=new Uint8ClampedArray(width*width*4).fill(255);
 for(let y=0;y<qr.modules.size;y++)for(let x=0;x<qr.modules.size;x++)if(qr.modules.get(y,x))for(let sy=0;sy<scale;sy++)for(let sx=0;sx<scale;sx++){
  const offset=(((y+margin)*scale+sy)*width+(x+margin)*scale+sx)*4;
  pixels[offset]=pixels[offset+1]=pixels[offset+2]=0;
 }
 assert.equal(jsQR(pixels,width,width)?.data,text);
});
