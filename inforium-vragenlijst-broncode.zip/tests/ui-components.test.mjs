import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test, { after } from "node:test";
import { fileURLToPath } from "node:url";

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createServer } from "vite";

const root = fileURLToPath(new URL("..", import.meta.url));
const vite = await createServer({
  appType: "custom",
  configFile: false,
  root,
  resolve: { alias: { "@": root } },
  server: { middlewareMode: true },
});

after(async () => {
  await vite.close();
});

async function readCssTree(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const contents = await Promise.all(
    entries.map(async (entry) => {
      const entryPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        return readCssTree(entryPath);
      }
      return entry.name.endsWith(".css") ? readFile(entryPath, "utf8") : "";
    }),
  );
  return contents.join("\n");
}

test("emits the application's accessible responsive stylesheet", async () => {
  const css = await readCssTree(path.join(root, "dist"));
  assert.match(css, /focus-visible/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(css, /intake-option/);
  assert.match(css, /intake-summary/);
});

test("forwards progress semantics to the primitive", async () => {
  const { Progress } = await vite.ssrLoadModule("/components/ui/progress.tsx");
  const html = renderToStaticMarkup(React.createElement(Progress, { value: 37 }));

  assert.match(html, /aria-valuenow="37"/);
  assert.match(html, /aria-valuetext="37%"/);
  assert.match(html, /data-state="loading"/);
});

test("emits chart themes for the starter's media dark mode", async () => {
  const { ChartStyle } = await vite.ssrLoadModule("/components/ui/chart.tsx");
  const html = renderToStaticMarkup(
    React.createElement(ChartStyle, {
      id: "contract",
      config: {
        latency: { theme: { light: "#ffffff", dark: "#000000" } },
      },
    }),
  );

  assert.match(html, /\[data-chart=contract\]/);
  assert.match(html, /@media \(prefers-color-scheme: dark\)/);
  assert.doesNotMatch(html, /\.dark/);
});

test("renders sidebar skeletons deterministically", async () => {
  const { SidebarMenuSkeleton } = await vite.ssrLoadModule(
    "/components/ui/sidebar.tsx",
  );
  const first = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));
  const second = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));

  assert.equal(first, second);
  assert.match(first, /--skeleton-width:70%/);
});

test('short result exposes the original sharing routes even with all questions skipped', async () => {
  const {default: ResultSharing}=await vite.ssrLoadModule('/components/result-sharing.tsx');
  const result={questionnaire:{title:'Korte vragenlijst',version:'1.0'},completedAt:'2026-10-10T12:00:00Z',responses:[{questionId:'reason',question:'Waar komt u voor?',answer:null},{questionId:'medication',question:'Wat gebruikt u aan medicijnen?',answer:null},{questionId:'operations',question:'Bent u eerder geopereerd?',answer:null}]};
  const html=renderToStaticMarkup(React.createElement(ResultSharing,{result,recipientEmail:'m.oei@mediwebs.nl',secureUrl:'https://www.zodos.nl/',onEdit(){},onReset(){}}));
  for(const text of ['Download en open veilig','Kies een deel-app','Download en open e-mail','Download PDF','Download JSON','Print antwoorden','Maak QR van korte samenvatting','m.oei@mediwebs.nl','0 van 3 vragen','Niet ingevuld'])assert.ok(html.includes(text),text);
  assert.doesNotMatch(html,/Totaalscore/);
});

test('result sharing does not offer an unsafe configured portal link', async () => {
  const {default: ResultSharing}=await vite.ssrLoadModule('/components/result-sharing.tsx');
  const html=renderToStaticMarkup(React.createElement(ResultSharing,{result:{questionnaire:{title:'Demo',version:'1.0'},completedAt:'2026-10-10T12:00:00Z',responses:[]},recipientEmail:'m.oei@mediwebs.nl',secureUrl:'javascript:alert(1)',onEdit(){},onReset(){}}));
  assert.doesNotMatch(html,/Download en open veilig/);
});
