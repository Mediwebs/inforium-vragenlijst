import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import ts from 'typescript';
const source=await readFile(new URL('../lib/intake.ts',import.meta.url),'utf8');
const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const {intakeSections,visible,validateSection,makeIntakeResult,generalIntakeDefinition,encodeIntakeDefinition,decodeIntakeDefinition,intakeDefinitionProblems}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
test('hidden conditional answers are excluded after the parent is changed',()=>{
const result=makeIntakeResult({name:'Demo',operations:'no',operationDetails:'stale hidden answer',smoking:'never',cigarettes:'20',smokingYears:'10'},'nl');
assert.ok(!result.responses.some(r=>r.questionId==='operationDetails'));
assert.ok(!result.responses.some(r=>r.questionId==='cigarettes'));
assert.equal(result.derived.packYears,null);
});
test('required follow-up appears only when applicable',()=>{
const section=intakeSections.find(s=>s.id==='history');
assert.deepEqual(validateSection(section,{conditions:'no'},'nl'),[]);
assert.equal(validateSection(section,{conditions:'yes'},'nl').length,1);
assert.deepEqual(validateSection(section,{conditions:'unknown'},'nl'),[]);
});
test('missing smoking quantity is unknown rather than zero; known inputs calculate pack years',()=>{
assert.equal(makeIntakeResult({smoking:'current'},'nl').derived.packYears,null);
assert.equal(makeIntakeResult({smoking:'former',cigarettes:'10',smokingYears:'20'},'nl').derived.packYears,10);
});
test('rejects invalid dates, future dates and alcohol days outside a week',()=>{
const identity=intakeSections[0];const base={name:'Demo',reason:'Voorbeeld'};
for(const dob of ['2023-02-29','2999-01-01','not a date'])assert.ok(validateSection(identity,{...base,dob},'nl').length>0);
assert.deepEqual(validateSection(identity,{...base,dob:'1980-02-29'},'nl'),[]);
assert.ok(validateSection(intakeSections.find(s=>s.id==='alcohol'),{alcohol:'current',alcoholDays:'8',substances:'no'},'nl').length>0);
});
test('language preserves structured answer codes and changes readable labels',()=>{
const answers={conditions:'no'};
const nl=makeIntakeResult(answers,'nl').responses.find(r=>r.questionId==='conditions');
const en=makeIntakeResult(answers,'en').responses.find(r=>r.questionId==='conditions');
assert.equal(nl.value,en.value);assert.equal(nl.answer,'Nee');assert.equal(en.answer,'No');
});

test('builder links preserve intake types, conditions, codes and fixed question numbers',()=>{
 const d=structuredClone(generalIntakeDefinition);d.code='INF-MIJN-001';d.title=['Eigen intake','Custom intake'];d.sections[0].fields=d.sections[0].fields.filter(f=>f.id!=='email');
 const decoded=decodeIntakeDefinition('#intake='+encodeIntakeDefinition(d));
 assert.deepEqual(decoded,d);assert.deepEqual(intakeDefinitionProblems(d),[]);
 const result=makeIntakeResult({name:'Demo',operations:'yes',operationDetails:'Voorbeeld'},'nl',decoded);
 assert.equal(result.questionnaire.code,'INF-MIJN-001');assert.equal(result.questionnaire.title,'Eigen intake');
 assert.equal(result.responses.find(r=>r.questionId==='phone').questionNumber,4);assert.ok(result.responses.some(r=>r.questionId==='operationDetails'));
 assert.ok(!makeIntakeResult({operations:'no'},'nl',decoded).responses.some(r=>r.questionId==='operationDetails'));
});
test('invalid builder definitions are rejected rather than opening the default intake',()=>{
 assert.equal(decodeIntakeDefinition('#intake=broken'),null);
 const d=structuredClone(generalIntakeDefinition);d.sections[0].fields[1].questionNumber=1;
 assert.equal(decodeIntakeDefinition('#intake='+encodeIntakeDefinition(d)),null);
});
