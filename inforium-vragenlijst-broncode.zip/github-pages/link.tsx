import React from 'react';
export default function Link({href,children,...props}:React.AnchorHTMLAttributes<HTMLAnchorElement>){
 const target=href==='/'?'./':href?.startsWith('/')?'https://inforium-vragenlijst.maroei.chatgpt.site'+href:href;
 return <a {...props} href={target}>{children}</a>;
}
