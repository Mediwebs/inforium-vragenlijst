import React from 'react';
import {questionnaireUrl} from '@/lib/invullink';
export default function Link({href,children,...props}:React.AnchorHTMLAttributes<HTMLAnchorElement>){
 const target=href?.startsWith('/')?questionnaireUrl(href):href;
 return <a {...props} href={target}>{children}</a>;
}
