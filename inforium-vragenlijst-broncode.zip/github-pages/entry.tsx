import React from 'react';
import {createRoot} from 'react-dom/client';
import ShortQuestionnaire from '@/components/short-questionnaire';
createRoot(document.getElementById('root')!).render(<ShortQuestionnaire/>);
