"use client";
import {useEffect,useState} from 'react';
import ShortQuestionnaire from '@/components/short-questionnaire';
import EssQuestionnaire from '@/components/ess-questionnaire';
export default function Home(){
 const [custom,setCustom]=useState(false);
 useEffect(()=>{const sync=()=>setCustom(window.location.hash.startsWith('#q='));sync();window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync);},[]);
 return custom?<EssQuestionnaire/>:<ShortQuestionnaire/>;
}
