export {default} from '@/components/short-questionnaire';
