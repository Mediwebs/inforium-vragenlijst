"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Check,
  Copy,
  ExternalLink,
  FilePlus2,
  GripVertical,
  LockKeyhole,
  Plus,
  ShieldCheck,
  Trash2,
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  encodeDefinition,
  essDemoDefinition,
  isValidEmail,
  safeHttpUrl,
  type QuestionnaireDefinition,
} from "@/lib/questionnaire";

export default function MakerPage() {
  const [definition, setDefinition] = useState<QuestionnaireDefinition>(essDemoDefinition);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [validated, setValidated] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState("");
  const [copied, setCopied] = useState(false);

  const problems = useMemo(() => {
    const result: string[] = [];
    if (definition.title.trim().length < 3) result.push("Geef de vragenlijst een titel.");
    if (definition.organization.trim().length < 2) result.push("Vul de organisatie in.");
    if (!isValidEmail(definition.recipientEmail)) {
      result.push("Vul een geldig e-mailadres voor de ontvanger in.");
    }
    if (definition.secureUrl && !safeHttpUrl(definition.secureUrl)) {
      result.push("Vul een volledige veilige link in, beginnend met https://.");
    }
    if (definition.questions.length < 1) result.push("Voeg minimaal één vraag toe.");
    if (definition.questions.some((question) => question.text.trim().length < 2)) {
      result.push("Vul alle vraagteksten in.");
    }
    return result;
  }, [definition]);

  function update<Key extends keyof QuestionnaireDefinition>(
    key: Key,
    value: QuestionnaireDefinition[Key],
  ) {
    setDefinition((current) => ({ ...current, [key]: value }));
    setPublishedUrl("");
  }

  function createLink() {
    if (problems.length || !rightsConfirmed || !validated) return;
    const finalDefinition: QuestionnaireDefinition = {
      ...definition,
      id: globalThis.crypto?.randomUUID?.() ?? `vragenlijst-${Date.now()}`,
      version: definition.version || "1.0",
      demoOnly: false,
    };
    setPublishedUrl(`${window.location.origin}/#q=${encodeDefinition(finalDefinition)}`);
    setCopied(false);
  }

  async function copyLink() {
    if (!publishedUrl) return;
    await navigator.clipboard.writeText(publishedUrl);
    setCopied(true);
  }

  return (
    <main className="app-shell maker-shell">
      <nav className="topbar" aria-label="Hoofdnavigatie">
        <Link className="brand" href="/">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span>
            Inforium <strong>Vragenlijst</strong>
          </span>
        </Link>
        <Link className="maker-link" href="/">
          <ArrowLeft aria-hidden="true" /> Bekijk patiëntdemo
        </Link>
      </nav>

      <div className="maker-layout">
        <aside className="maker-aside">
          <p className="eyebrow">Vragenlijstgenerator</p>
          <h1>Van vragen naar een veilige invullink</h1>
          <p>
            Maak een formulier zonder database. De definitie zit in de link; patiëntantwoorden
            blijven lokaal op het apparaat.
          </p>
          <ol className="maker-steps">
            <li className="active">
              <span>1</span>
              <div>
                <strong>Inhoud</strong>
                <small>Titel, route en vragen</small>
              </div>
            </li>
            <li>
              <span>2</span>
              <div>
                <strong>Controle</strong>
                <small>Rechten en validatie</small>
              </div>
            </li>
            <li>
              <span>3</span>
              <div>
                <strong>Publiceer</strong>
                <small>Maak de deelbare link</small>
              </div>
            </li>
          </ol>
          <div className="aside-privacy">
            <LockKeyhole />
            <span>
              <strong>Geen patiëntendatabase</strong>
              Antwoorden gaan niet via deze website.
            </span>
          </div>
        </aside>

        <div className="maker-main">
          <header className="maker-heading">
            <div>
              <p className="eyebrow">Conceptinstellingen</p>
              <h2>Uw vragenlijst</h2>
            </div>
            <span className="draft-pill">Concept</span>
          </header>

          <Alert className="license-alert">
            <ShieldCheck aria-hidden="true" />
            <AlertTitle>Voor deze demo wordt de ESS-licentie verondersteld</AlertTitle>
            <AlertDescription>
              De vragen, antwoordscore en resultaatcategorieën zijn ingevuld voor functioneel testen.
              Controleer voor productie de exacte gelicentieerde Nederlandse versie.
            </AlertDescription>
          </Alert>

          <section className="maker-section">
            <div className="section-heading">
              <span>01</span>
              <div>
                <h3>Basisgegevens</h3>
                <p>Wat ziet de patiënt bovenaan?</p>
              </div>
            </div>
            <div className="maker-fields two-columns">
              <div className="field-group full-width">
                <Label htmlFor="title">Titel vragenlijst</Label>
                <Input
                  id="title"
                  value={definition.title}
                  onChange={(event) => update("title", event.target.value)}
                />
              </div>
              <div className="field-group">
                <Label htmlFor="organization">Organisatie</Label>
                <Input
                  id="organization"
                  value={definition.organization}
                  onChange={(event) => update("organization", event.target.value)}
                />
              </div>
              <div className="field-group">
                <Label htmlFor="version">Versie</Label>
                <Input
                  id="version"
                  value={definition.version}
                  onChange={(event) => update("version", event.target.value)}
                />
              </div>
              <div className="field-group full-width">
                <Label htmlFor="description">Korte uitleg</Label>
                <Textarea
                  id="description"
                  value={definition.description}
                  onChange={(event) => update("description", event.target.value)}
                />
              </div>
              <div className="field-group full-width">
                <Label htmlFor="instructions">Invulinstructie</Label>
                <Textarea
                  id="instructions"
                  value={definition.instructions}
                  onChange={(event) => update("instructions", event.target.value)}
                />
              </div>
            </div>
          </section>

          <section className="maker-section">
            <div className="section-heading">
              <span>02</span>
              <div>
                <h3>Ontvangst en veilige route</h3>
                <p>Waar kan de patiënt het resultaat zelf naartoe sturen?</p>
              </div>
            </div>
            <div className="maker-fields two-columns">
              <div className="field-group">
                <Label htmlFor="recipient">E-mailadres ontvanger</Label>
                <Input
                  id="recipient"
                  type="email"
                  value={definition.recipientEmail}
                  onChange={(event) => update("recipientEmail", event.target.value)}
                />
                <small>Wordt alleen gebruikt om het mailconcept te adresseren.</small>
              </div>
              <div className="field-group">
                <Label htmlFor="secure-url">Link naar portaal of ZODOS</Label>
                <Input
                  id="secure-url"
                  type="url"
                  value={definition.secureUrl}
                  onChange={(event) => update("secureUrl", event.target.value)}
                  placeholder="https://..."
                />
                <small>Gebruik bij voorkeur een directe, ingerichte aanleverroute.</small>
              </div>
            </div>
          </section>

          <section className="maker-section">
            <div className="section-heading">
              <span>03</span>
              <div>
                <h3>Vragen en antwoordscore</h3>
                <p>De patiënt ziet steeds één vraag.</p>
              </div>
            </div>
            <div className="option-editor">
              <strong>Antwoordopties</strong>
              <div className="option-grid">
                {definition.answerOptions.map((option, index) => (
                  <div key={option.value}>
                    <span>{option.value}</span>
                    <Input
                      aria-label={`Label voor score ${option.value}`}
                      value={option.label}
                      onChange={(event) =>
                        update(
                          "answerOptions",
                          definition.answerOptions.map((item, itemIndex) =>
                            itemIndex === index ? { ...item, label: event.target.value } : item,
                          ),
                        )
                      }
                    />
                  </div>
                ))}
              </div>
            </div>
            <div className="question-editor-list">
              {definition.questions.map((question, index) => (
                <div className="question-editor" key={question.id}>
                  <GripVertical aria-hidden="true" />
                  <span className="question-index">{index + 1}</span>
                  <div>
                    <Label htmlFor={`question-${question.id}`}>Vraag {index + 1}</Label>
                    <Input
                      id={`question-${question.id}`}
                      value={question.text}
                      onChange={(event) =>
                        update(
                          "questions",
                          definition.questions.map((item, itemIndex) =>
                            itemIndex === index ? { ...item, text: event.target.value } : item,
                          ),
                        )
                      }
                    />
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label={`Verwijder vraag ${index + 1}`}
                    disabled={definition.questions.length === 1}
                    onClick={() =>
                      update(
                        "questions",
                        definition.questions.filter((_, itemIndex) => itemIndex !== index),
                      )
                    }
                  >
                    <Trash2 aria-hidden="true" />
                  </Button>
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                update("questions", [
                  ...definition.questions,
                  {
                    id: globalThis.crypto?.randomUUID?.() ?? `vraag-${Date.now()}`,
                    text: "Nieuwe vraag",
                  },
                ])
              }
            >
              <Plus aria-hidden="true" /> Voeg vraag toe
            </Button>
          </section>

          <section className="maker-section">
            <div className="section-heading">
              <span>04</span>
              <div>
                <h3>Bron, rechten en validatie</h3>
                <p>Maak herkomst en verantwoordelijkheid zichtbaar.</p>
              </div>
            </div>
            <div className="maker-fields two-columns">
              <div className="field-group">
                <Label htmlFor="source-title">Bronvermelding</Label>
                <Input
                  id="source-title"
                  value={definition.sourceTitle}
                  onChange={(event) => update("sourceTitle", event.target.value)}
                />
              </div>
              <div className="field-group">
                <Label htmlFor="source-url">Bronlink</Label>
                <Input
                  id="source-url"
                  type="url"
                  value={definition.sourceUrl}
                  onChange={(event) => update("sourceUrl", event.target.value)}
                />
              </div>
              <div className="field-group full-width">
                <Label htmlFor="rights">Gebruiksrecht / licentienotitie</Label>
                <Textarea
                  id="rights"
                  value={definition.rightsNotice}
                  onChange={(event) => update("rightsNotice", event.target.value)}
                />
              </div>
            </div>
            <div className="confirm-list">
              <Label className="confirm-row">
                <input
                  type="checkbox"
                  checked={rightsConfirmed}
                  onChange={(event) => setRightsConfirmed(event.target.checked)}
                />
                <span>
                  <strong>Inhoudsrechten zijn geregeld</strong>
                  Ik mag deze exacte vraagteksten en vertaling publiceren.
                </span>
              </Label>
              <Label className="confirm-row">
                <input
                  type="checkbox"
                  checked={validated}
                  onChange={(event) => setValidated(event.target.checked)}
                />
                <span>
                  <strong>Inhoud en scoring zijn gevalideerd</strong>
                  De inhoudelijke maker blijft verantwoordelijk voor versie, score en interpretatie.
                </span>
              </Label>
            </div>
          </section>

          <section className="publish-panel">
            <div>
              <p className="eyebrow">Publiceren</p>
              <h3>Maak een deelbare invullink</h3>
              <p>
                De link bevat alleen de vragenlijstdefinitie. Naam, geboortedatum en antwoorden
                komen nooit in de link.
              </p>
            </div>
            {problems.length > 0 && (
              <ul className="problem-list">
                {problems.map((problem) => (
                  <li key={problem}>{problem}</li>
                ))}
              </ul>
            )}
            <Button
              size="lg"
              onClick={createLink}
              disabled={problems.length > 0 || !rightsConfirmed || !validated}
            >
              <FilePlus2 aria-hidden="true" /> Maak invullink
            </Button>
            {(!rightsConfirmed || !validated) && (
              <small>Bevestig eerst de twee verantwoordelijkheden hierboven.</small>
            )}

            {publishedUrl && (
              <div className="published-box" role="status">
                <Check aria-hidden="true" />
                <div>
                  <strong>De invullink is klaar</strong>
                  <span>
                    {publishedUrl.length > 110
                      ? `${publishedUrl.slice(0, 110)}…`
                      : publishedUrl}
                  </span>
                </div>
                <Button variant="outline" onClick={copyLink}>
                  {copied ? <Check /> : <Copy />} {copied ? "Gekopieerd" : "Kopieer"}
                </Button>
                <Button asChild>
                  <a href={publishedUrl} target="_blank" rel="noreferrer">
                    Open test <ExternalLink />
                  </a>
                </Button>
              </div>
            )}
          </section>

          <Alert className="security-alert final-note">
            <LockKeyhole aria-hidden="true" />
            <AlertTitle>Voor productie is meer nodig dan techniek</AlertTitle>
            <AlertDescription>
              Leg ontvangerschap, bewaartermijnen, dossiervoering, veilige e-mail/portaalroute,
              logging en patiënteninformatie vast. Een partnercertificaat ontslaat de
              zorgorganisatie niet van haar eigen verantwoordelijkheid.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </main>
  );
}
