import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Inforium Vragenlijst",
  description:
    "Privacyvriendelijke online vragenlijsten met lokale PDF- en JSON-uitvoer.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  );
}
