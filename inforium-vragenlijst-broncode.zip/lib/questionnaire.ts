export type AnswerOption = {
  value: number;
  label: string;
};

export type QuestionnaireQuestion = {
  id: string;
  text: string;
  help?: string;
};

export type ScoreBand = {
  min: number;
  max: number;
  label: string;
  advice: string;
};

export type QuestionnaireDefinition = {
  schemaVersion: "1.0";
  id: string;
  version: string;
  title: string;
  organization: string;
  description: string;
  instructions: string;
  recipientEmail: string;
  secureUrl: string;
  sourceTitle: string;
  sourceUrl: string;
  rightsNotice: string;
  demoOnly: boolean;
  answerOptions: AnswerOption[];
  questions: QuestionnaireQuestion[];
  scoreBands?: ScoreBand[];
};

export type QuestionnaireResult = {
  schemaVersion: "1.0";
  questionnaire: {
    code?: string;
    id: string;
    version: string;
    title: string;
    organization: string;
    sourceTitle: string;
    sourceUrl: string;
  };
  patient: {
    name: string;
    dateOfBirth: string;
  };
  completedAt: string;
  score: {
    total: number;
    maximum: number;
    interpretation: string | null;
    advice: string | null;
  };
  responses: Array<{
    questionId: string;
    questionNumber?: number;
    question: string;
    value: number;
    answer: string;
  }>;
};

const essQuestions: QuestionnaireQuestion[] = [
  "zittend lezen",
  "televisiekijken",
  "inactief zitten in een openbare ruimte, bijvoorbeeld in een theater of tijdens een vergadering",
  "als passagier in een auto tijdens een rit van een uur zonder onderbreking",
  "liggend rusten in de namiddag wanneer de omstandigheden dit toelaten",
  "zittend praten met iemand",
  "rustig zitten na de lunch, zonder alcohol te hebben gedronken",
  "in een auto, terwijl u enkele minuten stilstaat in het verkeer",
].map((situation, index) => ({
  id: `ess-${index + 1}`,
  text: `Hoe groot is de kans dat u wegdommelt of in slaap valt tijdens ${situation}?`,
}));

export const essDemoDefinition: QuestionnaireDefinition = {
  schemaVersion: "1.0",
  id: "ess-1997-nl-demo",
  version: "1997-nl-demo-1.0",
  title: "Epworth Sleepiness Scale",
  organization: "Voorbeeld zorgorganisatie",
  description:
    "Deze vragenlijst brengt uw gebruikelijke kans op wegdommelen of in slaap vallen in acht dagelijkse situaties in kaart.",
  instructions:
    "Denk aan uw gewone leefpatroon in de afgelopen periode. Ook als u een situatie niet recent heeft meegemaakt, schat u in hoe het u waarschijnlijk zou vergaan. Beantwoord iedere vraag zo goed mogelijk.",
  recipientEmail: "m.oei@mediwebs.nl",
  secureUrl: "https://www.zodos.nl/",
  sourceTitle: "Epworth Sleepiness Scale © M.W. Johns 1990–1997",
  sourceUrl: "https://epworthsleepinessscale.com/about-the-ess/",
  rightsNotice:
    "Voor deze testdemo worden een geldige licentie en het recht op gebruik van de Nederlandse versie verondersteld. Leg dit voor productie vast in het contentpaspoort.",
  demoOnly: true,
  answerOptions: [
    { value: 0, label: "Zou nooit indutten" },
    { value: 1, label: "Kleine kans om in te dutten" },
    { value: 2, label: "Redelijke kans om in te dutten" },
    { value: 3, label: "Grote kans om in te dutten" },
  ],
  questions: essQuestions,
  scoreBands: [
    {
      min: 0,
      max: 5,
      label: "Lagere normale slaperigheid overdag",
      advice: "De score valt binnen het normale referentiegebied.",
    },
    {
      min: 6,
      max: 10,
      label: "Hogere normale slaperigheid overdag",
      advice: "De score valt nog binnen het normale referentiegebied.",
    },
    {
      min: 11,
      max: 12,
      label: "Lichte overmatige slaperigheid overdag",
      advice: "Bespreek de uitslag met uw zorgverlener als u klachten of zorgen heeft.",
    },
    {
      min: 13,
      max: 15,
      label: "Matige overmatige slaperigheid overdag",
      advice: "Bespreek deze uitslag met uw zorgverlener.",
    },
    {
      min: 16,
      max: 24,
      label: "Ernstige overmatige slaperigheid overdag",
      advice: "Neem contact op met uw zorgverlener om deze uitslag te bespreken.",
    },
  ],
};

export function encodeDefinition(definition: QuestionnaireDefinition): string {
  const bytes = new TextEncoder().encode(JSON.stringify(definition));
  let binary = "";
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary)
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
}

export function decodeDefinition(value: string): QuestionnaireDefinition | null {
  try {
    if (value.length > 100_000) return null;
    const padded = value.replaceAll("-", "+").replaceAll("_", "/");
    const binary = atob(padded + "=".repeat((4 - (padded.length % 4)) % 4));
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    const parsed = JSON.parse(new TextDecoder().decode(bytes)) as QuestionnaireDefinition;

    if (
      parsed.schemaVersion !== "1.0" ||
      typeof parsed.title !== "string" ||
      typeof parsed.organization !== "string" ||
      !Array.isArray(parsed.questions) ||
      parsed.questions.length < 1 ||
      parsed.questions.length > 50 ||
      !Array.isArray(parsed.answerOptions) ||
      parsed.answerOptions.length < 2 ||
      parsed.answerOptions.length > 10 ||
      parsed.answerOptions.some(
        (option) => !Number.isFinite(Number(option.value)) || Number(option.value) < 0 || Number(option.value) > 1_000,
      )
    ) {
      return null;
    }

    return {
      ...parsed,
      id: String(parsed.id || "vragenlijst").slice(0, 120),
      version: String(parsed.version || "1.0").slice(0, 40),
      title: parsed.title.slice(0, 220),
      organization: parsed.organization.slice(0, 180),
      description: String(parsed.description || "").slice(0, 1_000),
      instructions: String(parsed.instructions || "").slice(0, 1_000),
      recipientEmail: String(parsed.recipientEmail || "").slice(0, 254),
      secureUrl: String(parsed.secureUrl || "").slice(0, 2_000),
      sourceTitle: String(parsed.sourceTitle || "").slice(0, 500),
      sourceUrl: String(parsed.sourceUrl || "").slice(0, 2_000),
      rightsNotice: String(parsed.rightsNotice || "").slice(0, 1_000),
      demoOnly: Boolean(parsed.demoOnly),
      scoreBands: Array.isArray(parsed.scoreBands)
        ? parsed.scoreBands.slice(0, 20).map((band) => ({
            min: Number(band.min),
            max: Number(band.max),
            label: String(band.label || "").slice(0, 200),
            advice: String(band.advice || "").slice(0, 500),
          }))
        : undefined,
      questions: parsed.questions.map((question, index) => ({
        id: `${String(question.id || "vraag").slice(0, 60)}-${index + 1}`,
        text: String(question.text || `Vraag ${index + 1}`).slice(0, 500),
        help: question.help ? String(question.help).slice(0, 500) : undefined,
      })),
      answerOptions: parsed.answerOptions.map((option) => ({
        value: Number(option.value),
        label: String(option.label).slice(0, 120),
      })),
    };
  } catch {
    return null;
  }
}

export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export function safeHttpUrl(value: string): string | null {
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.href : null;
  } catch {
    return null;
  }
}
