import type { QuestionnaireResult } from "./questionnaire";

function ascii(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, "-")
    .replace(/…/g, "...")
    .replace(/[^\x20-\x7E]/g, "?");
}

function escapePdf(value: string): string {
  return ascii(value).replace(/([\\()])/g, "\\$1");
}

function wrap(value: string, width = 84): string[] {
  const words = ascii(value).split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = "";

  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (candidate.length > width && line) {
      lines.push(line);
      line = word;
    } else {
      line = candidate;
    }
  }
  if (line) lines.push(line);
  return lines.length ? lines : [""];
}

function displayDate(isoDate: string): string {
  if (/^\d{2}-\d{2}-\d{4}$/.test(isoDate)) return isoDate;
  const [year, month, day] = isoDate.split("-");
  return year && month && day ? `${day}-${month}-${year}` : isoDate;
}

export function resultLines(result: QuestionnaireResult): string[] {
  const lines = [
    result.questionnaire.title,
    result.questionnaire.organization,
    "",
    `Naam: ${result.patient.name}`,
    `Geboortedatum: ${displayDate(result.patient.dateOfBirth)}`,
    `Ingevuld op: ${new Date(result.completedAt).toLocaleString("nl-NL")}`,
    "",
    `Totaalscore: ${result.score.total} van ${result.score.maximum}`,
    `Duiding: ${result.score.interpretation ?? "niet ingesteld"}`,
    `Advies: ${result.score.advice ?? "Bespreek de uitslag zo nodig met uw zorgverlener."}`,
    "De ESS is geen zelfstandige diagnostische test.",
    "",
    "Antwoorden",
  ];

  result.responses.forEach((response, index) => {
    lines.push("");
    lines.push(...wrap(`${index + 1}. ${response.question}`));
    lines.push(`Antwoord: ${response.answer} (${response.value})`);
  });

  lines.push("");
  lines.push("Bron");
  lines.push(...wrap(result.questionnaire.sourceTitle));
  if (result.questionnaire.sourceUrl) lines.push(result.questionnaire.sourceUrl);
  lines.push("");
  lines.push("Dit document is door de invuller op het eigen apparaat gemaakt.");
  return lines;
}

export function createPdfBlob(result: QuestionnaireResult): Blob {
  return createTextPdfBlob(resultLines(result));
}

export function createTextPdfBlob(inputLines: string[]): Blob {
  const lines = inputLines.flatMap((line) => wrap(line));
  const linesPerPage = 46;
  const pages = Array.from(
    { length: Math.ceil(lines.length / linesPerPage) },
    (_, index) => lines.slice(index * linesPerPage, (index + 1) * linesPerPage),
  );

  const objects: string[] = [];
  const pageRefs = pages.map((_, index) => `${4 + index * 2} 0 R`).join(" ");
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[2] = `<< /Type /Pages /Kids [${pageRefs}] /Count ${pages.length} >>`;
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";

  pages.forEach((pageLines, index) => {
    const pageObject = 4 + index * 2;
    const contentObject = pageObject + 1;
    const text = [
      "BT",
      "/F1 10 Tf",
      "50 790 Td",
      "15 TL",
      ...pageLines.map((line) => `(${escapePdf(line)}) Tj T*`),
      "ET",
    ].join("\n");
    objects[pageObject] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] ` +
      `/Resources << /Font << /F1 3 0 R >> >> /Contents ${contentObject} 0 R >>`;
    objects[contentObject] = `<< /Length ${text.length} >>\nstream\n${text}\nendstream`;
  });

  let pdf = "%PDF-1.4\n% Inforium\n";
  const offsets = [0];
  for (let index = 1; index < objects.length; index += 1) {
    offsets[index] = pdf.length;
    pdf += `${index} 0 obj\n${objects[index]}\nendobj\n`;
  }
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length}\n`;
  pdf += "0000000000 65535 f \n";
  for (let index = 1; index < objects.length; index += 1) {
    pdf += `${String(offsets[index]).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([pdf], { type: "application/pdf" });
}
