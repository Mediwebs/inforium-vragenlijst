export function questionnaireUrl(path:string){
 const origin=typeof window==='undefined'?'https://inforium-vragenlijst.maroei.chatgpt.site':window.location.origin;
 if(typeof window!=='undefined'&&window.location.hostname.endsWith('.github.io')){
  const forms:Record<string,string>={'/':'short','/korte-demo':'short','/algemene-intake':'intake','/invullen/epworth':'epworth','/voorbeelden':'examples','/maken':'builder'};
  return origin+window.location.pathname+'?form='+(forms[path]??'short');
 }
 return origin+path;
}
