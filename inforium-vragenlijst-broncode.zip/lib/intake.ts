export type Language = 'nl' | 'en';
export type Answers = Record<string,string>;
export type Field = {id:string;questionNumber?:number;label:[string,string];type?:'text'|'textarea'|'date'|'email'|'tel'|'number'|'radio'|'select'|'checkbox';options?:[string,string,string][];required?:boolean;when?:[string,string[]];help?:[string,string];min?:number;max?:number};
export type Section={id:string;title:[string,string];fields:Field[]};
const yesNo:[string,string,string][]=[['yes','Ja','Yes'],['no','Nee','No'],['unknown','Weet ik niet','I do not know']];
const yes=(id:string,label:[string,string]):Field=>({id,label,options:yesNo,required:true});
const details=(id:string,label:[string,string],parent:string):Field=>({id,label,type:'textarea',when:[parent,['yes']],required:true});
export const intakeSections:Section[]=[
{id:'identity',title:['Over u','About you'],fields:[
{id:'name',label:['Naam (gebruik een fictieve naam)','Name (use a fictional name)'],required:true},
{id:'dob',label:['Geboortedatum','Date of birth'],type:'date',required:true},
{id:'email',label:['E-mailadres (optioneel)','Email address (optional)'],type:'email'},
{id:'phone',label:['Telefoonnummer (optioneel)','Phone number (optional)'],type:'tel'},
{id:'reason',label:['Waarom komt u naar de zorgverlener?','Why are you visiting your care provider?'],type:'textarea',required:true}]},
{id:'history',title:['Ziekten en gezondheid','Medical history'],fields:[yes('conditions',['Heeft u ziekten of langdurige klachten?','Do you have any illnesses or long-term symptoms?']),details('conditionDetails',['Welke ziekten of klachten? Sinds wanneer?','Which illnesses or symptoms? Since when?'],'conditions')]},
{id:'operations',title:['Operaties en opnames','Operations and hospital stays'],fields:[yes('operations',['Bent u eerder geopereerd?','Have you had an operation before?']),details('operationDetails',['Welke operatie(s), in welk jaar en waren er problemen?','Which operation(s), in which year, and were there any problems?'],'operations'),yes('admissions',['Bent u in een ziekenhuis opgenomen?','Have you stayed in hospital?']),details('admissionDetails',['Waarvoor en in welk jaar?','For what reason and in which year?'],'admissions')]},
{id:'medication',title:['Medicijnen','Medicines'],fields:[yes('medication',['Gebruikt u medicijnen? Ook zonder recept, vitamines en supplementen.','Do you use medicines? Include over-the-counter medicines, vitamins and supplements.']),{...details('medicationDetails',['Welke medicijnen gebruikt u?','Which medicines do you use?'],'medication'),help:['Zet elk medicijn op een nieuwe regel: naam, sterkte en hoe vaak u het gebruikt. Weet u dit niet? Schrijf dat erbij.','Use a new line for each medicine: name, strength and how often you take it. If you do not know, write that down.']},yes('bloodThinners',['Gebruikt u bloedverdunners?','Do you use blood-thinning medicines?']),details('bloodThinnerDetails',['Welke bloedverdunner(s)?','Which blood-thinning medicine(s)?'],'bloodThinners')]},
{id:'allergies',title:['Allergieën','Allergies'],fields:[yes('allergies',['Bent u allergisch voor iets? Bijvoorbeeld medicijnen of latex.','Are you allergic to anything? For example medicines or latex.']),details('allergyDetails',['Waarvoor bent u allergisch en wat gebeurt er dan?','What are you allergic to and what happens?'],'allergies')]},
{id:'smoking',title:['Roken en vapen','Smoking and vaping'],fields:[
{id:'smoking',label:['Rookt u?','Do you smoke?'],required:true,options:[['never','Nooit gerookt','Never smoked'],['former','Vroeger gerookt','Smoked in the past'],['current','Ik rook nu','I smoke now'],['unknown','Wil ik niet zeggen','Prefer not to say']]},
{id:'cigarettes',label:['Gemiddeld aantal sigaretten per dag','Average number of cigarettes per day'],type:'number',min:0,max:200,when:['smoking',['former','current']],help:['Laat leeg als u het niet weet of andere tabak gebruikt.','Leave blank if you do not know or use other tobacco.']},
{id:'smokingYears',label:['Hoeveel jaar heeft u in totaal gerookt?','For how many years have you smoked in total?'],type:'number',min:0,max:120,when:['smoking',['former','current']]},
{id:'stopped',label:['In welk jaar bent u gestopt?','In which year did you stop?'],type:'number',min:1900,max:2100,when:['smoking',['former']]},
{id:'otherTobacco',label:['Andere tabak, bijvoorbeeld sigaren of pijp (optioneel)','Other tobacco, for example cigars or pipe (optional)'],when:['smoking',['former','current']]},
yes('vaping',['Gebruikt u een e-sigaret (vape)?','Do you use an e-cigarette (vape)?'])]},
{id:'alcohol',title:['Alcohol en andere middelen','Alcohol and other substances'],fields:[
{id:'alcohol',label:['Drinkt u alcohol?','Do you drink alcohol?'],required:true,options:[['never','Nee','No'],['former','Vroeger, nu niet meer','In the past, but not now'],['current','Ja','Yes'],['private','Wil ik niet zeggen','Prefer not to say']]},
{id:'alcoholDays',label:['Op hoeveel dagen per week drinkt u gemiddeld?','On how many days per week do you usually drink?'],type:'number',min:0,max:7,when:['alcohol',['current']]},
{id:'alcoholGlasses',label:['Hoeveel standaardglazen drinkt u op een dag waarop u drinkt?','How many standard drinks on a day when you drink?'],type:'number',min:0,max:100,when:['alcohol',['current']],help:['Bijvoorbeeld een klein glas bier (250 ml), wijn (100 ml) of sterke drank (35 ml). Een groot glas telt voor meer.','For example 250 ml of beer, 100 ml of wine or 35 ml of spirits. A larger glass counts as more.']},
{id:'substances',label:['Gebruikt u drugs of andere middelen?','Do you use drugs or other substances?'],required:true,options:[...yesNo,['private','Wil ik niet zeggen','Prefer not to say']]},details('substanceDetails',['Welke middelen en hoe vaak?','Which substances and how often?'],'substances')]},
{id:'daily',title:['Dagelijks leven','Daily life'],fields:[{id:'height',label:['Lengte in centimeters (optioneel)','Height in centimetres (optional)'],type:'number',min:30,max:260},{id:'weight',label:['Gewicht in kilogram (optioneel)','Weight in kilograms (optional)'],type:'number',min:1,max:500},yes('limitations',['Heeft u hulp nodig bij dagelijkse dingen?','Do you need help with daily activities?']),details('limitationDetails',['Waarbij heeft u hulp nodig? Bijvoorbeeld lopen, horen, zien of begrijpen.','What do you need help with? For example walking, hearing, seeing or understanding.'],'limitations'),{id:'communication',label:['Wat helpt u in het gesprek? Bijvoorbeeld een tolk of iemand die meegaat.','What helps you during your appointment? For example an interpreter or someone joining you.'],type:'textarea'}]},
{id:'other',title:['Wat wilt u nog vertellen?','Anything else?'],fields:[{id:'other',label:['Andere informatie die uw zorgverlener moet weten (optioneel)','Other information your care provider should know (optional)'],type:'textarea'}]}
];
export function intakeQuestionNumber(id:string,sections:Section[]=intakeSections){const fields=sections.flatMap(s=>s.fields);return fields.find(f=>f.id===id)?.questionNumber??fields.findIndex(f=>f.id===id)+1;}
export function selectedValues(value:string|undefined):string[]{try{const a=JSON.parse(value||'[]');return Array.isArray(a)&&a.every(v=>typeof v==='string')?a:[];}catch{return [];}}
export function visible(f:Field,a:Answers,fields:Field[]=intakeSections.flatMap(s=>s.fields),seen=new Set<string>()):boolean{if(!f.when)return true;if(seen.has(f.id))return false;seen.add(f.id);const parent=fields.find(p=>p.id===f.when![0]);if(!parent||!visible(parent,a,fields,seen))return false;return parent.type==='checkbox'?selectedValues(a[parent.id]).some(v=>f.when![1].includes(v)):f.when[1].includes(a[parent.id]);}
export function validateSection(s:Section,a:Answers,l:Language,fields:Field[]=intakeSections.flatMap(s=>s.fields)):string[]{
const en=l==='en',errors:string[]=[];
for(const f of s.fields.filter(f=>visible(f,a,fields))){const v=(a[f.id]??'').trim(),label=f.label[en?1:0];
if(f.required&&(!v||(f.type==='checkbox'&&!selectedValues(v).length)))errors.push(en?`Please answer: ${label}`:`Vul in: ${label}`);if(!v)continue;
if(f.options&&(f.type==='checkbox'?(!(()=>{try{const a=JSON.parse(v);return Array.isArray(a)&&a.every(x=>typeof x==='string')}catch{return false}})()||selectedValues(v).some(x=>!f.options!.some(o=>o[0]===x))):!f.options.some(o=>o[0]===v)))errors.push(en?'Choose a valid answer.':'Kies een geldig antwoord.');
if(f.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))errors.push(en?'Enter a valid email address.':'Vul een geldig e-mailadres in.');
if(f.type==='number'&&(!Number.isFinite(Number(v))||Number(v)<(f.min??-Infinity)||Number(v)>(f.max??Infinity)))errors.push(en?`Check: ${label}`:`Controleer: ${label}`);
if(f.type==='date'){const d=new Date(v+'T00:00:00Z');if(!/^\d{4}-\d{2}-\d{2}$/.test(v)||!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==v||(f.id==='dob'&&(v<'1900-01-01'||v>new Date().toISOString().slice(0,10))))errors.push(en?'Enter a valid date.':'Vul een geldige datum in.');}
if(f.id==='stopped'&&Number(v)>new Date().getFullYear())errors.push(en?'The year cannot be in the future.':'Het jaar kan niet in de toekomst liggen.');
}return errors;}
export function makeIntakeResult(a:Answers,l:Language,definition:IntakeDefinition=generalIntakeDefinition){const intakeSections=definition.sections;const i=l==='nl'?0:1;const fields=intakeSections.flatMap(s=>s.fields);const responses=intakeSections.flatMap(s=>s.fields.filter(f=>visible(f,a,fields)).map(f=>({sectionId:s.id,questionId:f.id,questionNumber:intakeQuestionNumber(f.id,intakeSections),question:f.label[i],value:f.type==='checkbox'?(selectedValues(a[f.id]).length?selectedValues(a[f.id]):null):a[f.id]?.trim()||null,answer:f.type==='checkbox'?(f.options?.filter(o=>selectedValues(a[f.id]).includes(o[0])).map(o=>o[i+1]).join('; ')||null):f.options?.find(o=>o[0]===a[f.id])?.[i+1]??(a[f.id]?.trim()||null)})));
const known=['current','former'].includes(a.smoking)&&a.cigarettes?.trim()&&a.smokingYears?.trim();
return {schemaVersion:'1.0',questionnaire:{id:'general-medical-intake-demo',code:definition.code,version:definition.version,title:definition.title[i],sourceTitle:definition.sourceTitle,demoOnly:true},language:l,completedAt:new Date().toISOString(),responses,derived:{packYears:known?Math.round(Number(a.cigarettes)/20*Number(a.smokingYears)*10)/10:null},submittedToProvider:false};}

export type IntakeDefinition={kind:'intake';code:string;version:string;title:[string,string];description:[string,string];sourceTitle:string;sections:Section[]};
export const generalIntakeDefinition:IntakeDefinition={kind:'intake',code:'INF-INTAKE-001',version:'1.1',title:['Algemene medische intake','General medical intake'],description:['Vertel over uw gezondheid, medicijnen en dagelijks leven. Zo heeft u alles bij elkaar voor het gesprek.','Tell us about your health, medicines and daily life. Keep everything together for your appointment.'],sourceTitle:'Inforium — concept op basis van de gevraagde intakeonderdelen',sections:intakeSections.map(s=>({...s,fields:s.fields.map(f=>({...f,questionNumber:intakeQuestionNumber(f.id)}))}))};
export function intakeDefinitionProblems(d:IntakeDefinition){
 const problems:string[]=[];const fields=d.sections.flatMap(s=>s.fields);
 if(!/^[A-Z0-9][A-Z0-9-]{2,79}$/.test(d.code))problems.push('Gebruik voor de code 3–80 hoofdletters, cijfers en streepjes.');
 if(d.title.some(t=>t.trim().length<3)||!d.version.trim())problems.push('Vul de titel in beide talen en de versie in.');
 if(!d.sections.length||d.sections.length>20||new Set(d.sections.map(s=>s.id)).size!==d.sections.length||d.sections.some(s=>!s.fields.length||s.title.some(t=>!t.trim())))problems.push('Gebruik 1 tot 20 pagina’s met unieke ID’s, een titel in beide talen en minstens één vraag.');
 if(!fields.length||fields.length>100)problems.push('Gebruik 1 tot 100 vragen.');
 if(fields.some(f=>f.label.some(l=>l.trim().length<2)))problems.push('Vul elke vraag in beide talen in.');
 if(new Set(fields.map(f=>f.id)).size!==fields.length||new Set(fields.map(f=>f.questionNumber)).size!==fields.length||fields.some(f=>!Number.isInteger(f.questionNumber)||f.questionNumber!<1))problems.push('Elke vraag moet een uniek positief nummer en ID hebben.');
 if(fields.some(f=>f.when&&!fields.some(parent=>parent.id===f.when![0]&&parent.options&&f.when![1].every(v=>parent.options!.some(o=>o[0]===v)))))problems.push('Een vervolgvraag verwijst naar een ontbrekende vraag of antwoordoptie.');
 if(fields.some(f=>(['radio','select','checkbox'].includes(f.type??'')&&!f.options?.length)||(f.options&&(!f.options.length||f.options.length>50||new Set(f.options.map(o=>o[0])).size!==f.options.length||f.options.some(o=>o.some(v=>!v.trim()))))))problems.push('Keuzevragen hebben 1 tot 50 unieke opties nodig, met een tekst in beide talen.');
 if(fields.some((f,index)=>f.when&&(!f.when[1].length||!fields.slice(0,index).some(parent=>parent.id===f.when![0]))))problems.push('Zet een hoofdvraag vóór de bijbehorende vervolgvragen en kies minstens één antwoordvoorwaarde.');
 if(fields.some(f=>(f.min!==undefined&&!Number.isFinite(f.min))||(f.max!==undefined&&!Number.isFinite(f.max))||(f.min!==undefined&&f.max!==undefined&&f.min>f.max)))problems.push('Controleer de minimum- en maximumwaarden.');
 return problems;
}
export function encodeIntakeDefinition(d:IntakeDefinition){return btoa(Array.from(new TextEncoder().encode(JSON.stringify(d)),b=>String.fromCharCode(b)).join('')).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
export function decodeIntakeDefinition(hash:string):IntakeDefinition|null{
 try{const token=hash.replace(/^#intake=/,'');if(token.length>200000)return null;const value=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(token.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0))));
 const pair=(v:unknown)=>Array.isArray(v)&&v.length===2&&v.every(x=>typeof x==='string'&&x.length<=4000);
 if(value.kind!=='intake'||typeof value.code!=='string'||typeof value.version!=='string'||typeof value.sourceTitle!=='string'||!pair(value.title)||!pair(value.description)||!Array.isArray(value.sections)||value.sections.length>20)return null;
 if(!value.sections.every((s:Section)=>typeof s.id==='string'&&pair(s.title)&&Array.isArray(s.fields)&&s.fields.every(f=>typeof f.id==='string'&&pair(f.label)&&(!f.type||['text','textarea','date','email','tel','number','radio','select','checkbox'].includes(f.type))&&(!f.options||Array.isArray(f.options)&&f.options.every(o=>Array.isArray(o)&&o.length===3&&o.every(v=>typeof v==='string')))&&(!f.when||Array.isArray(f.when)&&f.when.length===2&&typeof f.when[0]==='string'&&Array.isArray(f.when[1])&&f.when[1].every(v=>typeof v==='string'))&&(!f.help||pair(f.help)))))return null;
 return intakeDefinitionProblems(value).length?null:value;
 }catch{return null;}
}
