import {decodeIntakeDefinition,encodeIntakeDefinition,type IntakeDefinition} from './intake';
export const INTAKE_STORAGE_KEY='inforium-builder-intakes-v1';
export type SavedIntake={id:string;savedAt:string;definition:IntakeDefinition};
type Store=Pick<Storage,'getItem'|'setItem'>;
export function parseIntakeFile(text:string):IntakeDefinition{
 if(text.length>150000)throw new Error('Dit bestand is te groot.');
 let value:unknown;try{value=JSON.parse(text);}catch{throw new Error('Dit is geen geldig JSON-bestand.');}
 const d=decodeIntakeDefinition('#intake='+encodeIntakeDefinition(value as IntakeDefinition));
 if(!d)throw new Error('Het bestand bevat geen geldige intakevragenlijst.');
 // Only questionnaire fields are kept; imported answers or other data are discarded.
 return {kind:'intake',code:d.code,version:d.version,title:d.title,description:d.description,sourceTitle:d.sourceTitle,sections:d.sections.map(s=>({id:s.id,title:s.title,fields:s.fields.map(f=>({id:f.id,questionNumber:f.questionNumber,label:f.label,...(f.type?{type:f.type}:{}),...(f.options?{options:f.options}:{}),...(typeof f.required==='boolean'?{required:f.required}:{}),...(f.when?{when:f.when}:{}),...(f.help?{help:f.help}:{}),...(Number.isFinite(f.min)?{min:f.min}:{}),...(Number.isFinite(f.max)?{max:f.max}:{})}))}))};
}
export function readSavedIntakes(storage:Store):SavedIntake[]{
 const text=storage.getItem(INTAKE_STORAGE_KEY);if(!text)return [];
 const value=JSON.parse(text);if(!Array.isArray(value)||value.length>100)throw new Error('Ongeldige opslag.');
 const items=value.map(v=>{if(typeof v.id!=='string'||typeof v.savedAt!=='string'||!Number.isFinite(Date.parse(v.savedAt)))throw new Error('Ongeldige opslag.');return {id:v.id,savedAt:v.savedAt,definition:parseIntakeFile(JSON.stringify(v.definition))};});
 if(new Set(items.map(v=>v.id)).size!==items.length)throw new Error('Dubbele opslag-ID.');return items;
}
export function writeSavedIntakes(storage:Store,items:SavedIntake[]){
 if(items.length>100)throw new Error('U kunt maximaal 100 vragenlijsten in deze browser bewaren.');
 storage.setItem(INTAKE_STORAGE_KEY,JSON.stringify(items));
}
