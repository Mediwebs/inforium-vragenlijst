export const QR_SUMMARY_MAX_BYTES = 800;
export type SummaryResponse = {questionId:string;questionNumber?:number;question:string;answer:string|null};
export function makeQrSummary(questionnaireCode:string,responses:SummaryResponse[],selected:string[]){
  return [questionnaireCode,...responses.map((r,index)=>({...r,questionNumber:r.questionNumber??index+1})).filter(r=>selected.includes(r.questionId)).map(r=>r.questionNumber+': '+(r.answer??'Niet ingevuld'))].join('\n');
}
export function qrByteLength(text:string){return new TextEncoder().encode(text).length;}
export function validateQrSummary(text:string){
  if(!text.trim())return 'Vul een korte samenvatting in.';
  if(qrByteLength(text)>QR_SUMMARY_MAX_BYTES)return 'De samenvatting is te lang. Kort de tekst in of laat een onderdeel weg. Er is niets afgekapt.';
  return null;
}
