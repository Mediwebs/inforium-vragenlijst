export const QR_SUMMARY_MAX_BYTES = 800;
export type SummaryResponse = {questionId:string;question:string;answer:string|null};
export function makeQrSummary(title:string,responses:SummaryResponse[],selected:string[]){
  return ['Inforium DEMO — '+title,...responses.filter(r=>selected.includes(r.questionId)).map(r=>r.question+' '+(r.answer??'Niet ingevuld'))].join('\n');
}
export function qrByteLength(text:string){return new TextEncoder().encode(text).length;}
export function validateQrSummary(text:string){
  if(!text.trim())return 'Vul een korte samenvatting in.';
  if(qrByteLength(text)>QR_SUMMARY_MAX_BYTES)return 'De samenvatting is te lang. Kort de tekst in of laat een onderdeel weg. Er is niets afgekapt.';
  return null;
}
