"use client";
import {questionnaireFilename} from '@/lib/download-name';
import {useState} from 'react';
import QrSummary from '@/components/qr-summary';
import {ArrowRight,Check,ExternalLink,FileJson,FileText,LockKeyhole,Mail,Printer,RotateCcw,ShieldCheck,Sparkles} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Alert,AlertTitle,AlertDescription} from '@/components/ui/alert';
import {createTextPdfBlob} from '@/lib/pdf';
import {isValidEmail,safeHttpUrl} from '@/lib/questionnaire';
type Result={questionnaire:{title:string;version:string;code?:string};completedAt:string;responses:{questionId:string;questionNumber?:number;question:string;answer:string|null}[]};
function download(blob:Blob,name:string){const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export default function ResultSharing({result,recipientEmail,secureUrl,onEdit,onReset}:{result:Result;recipientEmail:string;secureUrl:string;onEdit:()=>void;onReset:()=>void}){
const [state,setState]=useState<'idle'|'shared'|'downloaded'|'error'>('idle');const secureTarget=safeHttpUrl(secureUrl);
function lines(){return [`Vragenlijst ${result.questionnaire.code??'INF-KORT-001'}: ${result.questionnaire.title}`,'Inforium — DEMO',`Versie: ${result.questionnaire.version}`,`Ingevuld op: ${new Date(result.completedAt).toLocaleString('nl-NL')}`,'',...result.responses.flatMap((r,i)=>[`${r.questionNumber??i+1}. ${r.question}`,r.answer??'Niet ingevuld','']),'Dit overzicht is lokaal op het apparaat van de invuller gemaakt.'];}
function files(){const base=questionnaireFilename(result.questionnaire.title,result.questionnaire.version);const pdf=createTextPdfBlob(lines());const json=new Blob([JSON.stringify(result,null,2)],{type:'application/json'});return {pdf,json,pdfFile:new File([pdf],base+'.pdf',{type:'application/pdf'}),jsonFile:new File([json],base+'.json',{type:'application/json'})};}
function downloadBoth(){const f=files();download(f.pdf,f.pdfFile.name);download(f.json,f.jsonFile.name);setState('downloaded');}
function mailBody(){return ['Beste zorgverlener,','',...lines(),'','De PDF en JSON zijn lokaal gemaakt. Voeg de bestanden zelf als bijlage toe.'].join('\n');}
async function share(){const f=files();try{if(navigator.share&&navigator.canShare?.({files:[f.pdfFile,f.jsonFile]})){await navigator.share({title:result.questionnaire.title,text:mailBody(),files:[f.pdfFile,f.jsonFile]});setState('shared');}else downloadBoth();}catch(error){if(error instanceof DOMException&&error.name==='AbortError')return;setState('error');}}
function mail(){downloadBoth();const recipient=isValidEmail(recipientEmail)?recipientEmail:'';window.location.href=`mailto:${encodeURIComponent(recipient)}?subject=${encodeURIComponent(result.questionnaire.title)}&body=${encodeURIComponent(mailBody())}`;}
function secure(){if(!secureTarget)return;window.open(secureTarget,'_blank','noopener,noreferrer');downloadBoth();}
return <>
<section className="result-hero" aria-labelledby="result-title"><div className="success-mark" aria-hidden="true"><Check/></div><p className="eyebrow">Klaar om te delen</p><h1 id="result-title">Uw antwoorden zijn overzichtelijk gemaakt</h1><p>Er is niets naar deze website verstuurd. Kies hieronder zelf waar u de PDF en JSON naartoe stuurt.</p></section>
<section className="identity-card short-result-meta"><p><span>Vragenlijst</span><strong>{result.questionnaire.code??'INF-KORT-001'}. {result.questionnaire.title}</strong></p><p><span>Ingevuld</span><strong>{result.responses.filter(r=>r.answer!==null).length} van {result.responses.length} vragen</strong></p><p><span>Versie</span><strong>{result.questionnaire.version}</strong></p></section>
<Alert className="security-alert"><ShieldCheck/><AlertTitle>Gebruik bij medische gegevens bij voorkeur de veilige route</AlertTitle><AlertDescription>Gewone e-mail is niet automatisch veilig. Gebruik voor gevoelige gegevens een portaal of een ingerichte ZODOS-route. Deze demo gebruikt alleen fictieve gegevens.</AlertDescription></Alert>
<section className="action-grid" aria-label="Deelopties">
{secureTarget&&<article className="action-card preferred"><span className="preferred-label">Voorkeur</span><LockKeyhole/><h2>Veilige omgeving</h2><p>Download beide bestanden en ga daarna naar de ingestelde omgeving. Deze demo opent de ZODOS-website; er is geen automatische overdracht of upload.</p><Button size="lg" onClick={secure}>Download en open veilig <ExternalLink/></Button></article>}
<article className="action-card"><Sparkles/><h2>Deel PDF + JSON</h2><p>Op geschikte telefoons en tablets opent dit het deelmenu met beide bestanden als bijlage.</p><Button size="lg" variant="outline" onClick={share}>Kies een deel-app <ArrowRight/></Button></article>
<article className="action-card"><Mail/><h2>E-mail naar Mediwebs</h2><p>Het mailconcept opent voor <strong>{recipientEmail}</strong> en bevat alle antwoorden. Voeg de gedownloade bestanden zelf als bijlage toe.</p><Button size="lg" variant="outline" onClick={mail}>Download en open e-mail <Mail/></Button></article>
</section>
{state==='downloaded'&&<p className="status-message" role="status">PDF en JSON zijn gedownload. Voeg ze zelf als bijlage toe. Er is niets automatisch verstuurd.</p>}
{state==='shared'&&<p className="status-message" role="status">Het deelmenu is geopend.</p>}
{state==='error'&&<p className="error-message" role="alert">Delen lukte niet. Probeer de e-mailroute of download opnieuw.</p>}
<div className="intake-downloads"><Button variant="outline" onClick={()=>{const f=files();download(f.pdf,f.pdfFile.name);}}><FileText/>Download PDF</Button><Button variant="outline" onClick={()=>{const f=files();download(f.json,f.jsonFile.name);}}><FileJson/>Download JSON</Button><Button variant="outline" onClick={()=>window.print()}><Printer/>Print antwoorden</Button></div>
<details className="download-details"><summary>Hoe werkt downloaden en e-mailen?</summary><div><p>De PDF en JSON worden pas na uw klik lokaal op dit apparaat gemaakt. Er wordt niets automatisch door deze website verstuurd.</p><p>Het mailconcept aan <strong>{recipientEmail}</strong> bevat de vragenlijst en alle antwoorden. Controleer de mail, voeg de downloads als bijlage toe en druk zelf op verzenden.</p></div></details>
<details className="answer-details"><summary>Bekijk alle antwoorden</summary><ol>{result.responses.map(r=><li key={r.questionId}><strong>{r.question}</strong><span className="short-answer">{r.answer??'Niet ingevuld'}</span></li>)}</ol></details>
<QrSummary questionnaireCode={result.questionnaire.code??'INF-KORT-001'} title={result.questionnaire.title} responses={result.responses}/>
<section className="print-answer-summary"><h2>Uw antwoorden</h2><p>Ingevuld op: {new Date(result.completedAt).toLocaleString('nl-NL')}</p>{result.responses.map(r=><div className="print-answer" key={r.questionId}><h3>{r.questionNumber}. {r.question}</h3><p>{r.answer??'Niet ingevuld'}</p></div>)}</section>
<div className="file-row" aria-label="Bestandsformaten"><span><FileText/>Leesbare PDF</span><span><FileJson/>Verwerkbare JSON</span><span><ShieldCheck/>Lokaal gemaakt</span></div>
<div className="intake-downloads"><Button variant="outline" onClick={onEdit}>Antwoorden aanpassen</Button><Button variant="ghost" onClick={onReset}><RotateCcw/>Wis gegevens en begin opnieuw</Button></div>
</>;
}
