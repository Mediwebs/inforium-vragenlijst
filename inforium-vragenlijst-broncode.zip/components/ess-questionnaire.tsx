"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ExternalLink,
  FileJson,
  FileText,
  LockKeyhole,
  Mail,
  RotateCcw,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { createPdfBlob } from "@/lib/pdf";
import {
  decodeDefinition,
  essDemoDefinition,
  isValidEmail,
  safeHttpUrl,
  type QuestionnaireDefinition,
  type QuestionnaireResult,
} from "@/lib/questionnaire";

type Answers = Record<string, number>;
type ShareState = "idle" | "shared" | "downloaded" | "error";

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function slug(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

function formatDate(value: string) {
  if (!value) return "—";
  const isoMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (isoMatch) return `${isoMatch[3]}-${isoMatch[2]}-${isoMatch[1]}`;
  return value;
}

function formatDateInput(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
  return `${digits.slice(0, 2)}-${digits.slice(2, 4)}-${digits.slice(4)}`;
}

function parseDutchDate(value: string) {
  const match = /^(\d{2})-(\d{2})-(\d{4})$/.exec(value);
  if (!match) return null;

  const day = Number(match[1]);
  const month = Number(match[2]);
  const year = Number(match[3]);
  const candidate = new Date(Date.UTC(year, month - 1, day));
  if (
    candidate.getUTCFullYear() !== year ||
    candidate.getUTCMonth() !== month - 1 ||
    candidate.getUTCDate() !== day
  ) {
    return null;
  }

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function todayAsIso() {
  const today = new Date();
  return [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, "0"),
    String(today.getDate()).padStart(2, "0"),
  ].join("-");
}

export default function Home() {
  const [definition, setDefinition] = useState<QuestionnaireDefinition>(essDemoDefinition);
  const [definitionError, setDefinitionError] = useState(false);
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [answers, setAnswers] = useState<Answers>({});
  const [errors, setErrors] = useState<string[]>([]);
  const [completed, setCompleted] = useState<QuestionnaireResult | null>(null);
  const [shareState, setShareState] = useState<ShareState>("idle");

  useEffect(() => {
    const hash = window.location.hash;
    if (!hash.startsWith("#q=")) return;
    const timer = window.setTimeout(() => {
      const decoded = decodeDefinition(hash.slice(3));
      if (decoded) {
        setDefinition(decoded);
        setDefinitionError(false);
      } else {
        setDefinitionError(true);
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const totalSteps = definition.questions.length + 2;
  const isReview = step === definition.questions.length + 1;
  const currentQuestion = step > 0 && !isReview ? definition.questions[step - 1] : null;
  const maximum =
    definition.questions.length * Math.max(...definition.answerOptions.map((item) => item.value));
  const total = Object.values(answers).reduce((sum, answer) => sum + answer, 0);
  const scoreBand = definition.scoreBands?.find((band) => total >= band.min && total <= band.max);
  const progress = completed ? 100 : Math.round(((step + 1) / totalSteps) * 100);

  const result = useMemo<QuestionnaireResult | null>(() => {
    if (!completed && !isReview) return null;
    return {
      schemaVersion: "1.0",
      questionnaire: {
        id: definition.id,
        version: definition.version,
        title: definition.title,
        organization: definition.organization,
        sourceTitle: definition.sourceTitle,
        sourceUrl: definition.sourceUrl,
      },
      patient: {
        name: name.trim(),
        dateOfBirth: parseDutchDate(dateOfBirth) ?? dateOfBirth,
      },
      completedAt: completed?.completedAt ?? new Date().toISOString(),
      score: {
        total,
        maximum,
        interpretation: scoreBand?.label ?? null,
        advice: scoreBand?.advice ?? null,
      },
      responses: definition.questions.map((question) => {
        const value = answers[question.id];
        return {
          questionId: question.id,
          question: question.text,
          value,
          answer:
            definition.answerOptions.find((option) => option.value === value)?.label ??
            String(value),
        };
      }),
    };
  }, [answers, completed, dateOfBirth, definition, isReview, maximum, name, scoreBand, total]);

  function validateIdentity() {
    const nextErrors: string[] = [];
    if (name.trim().length < 2) nextErrors.push("Vul uw naam in.");
    if (!dateOfBirth) nextErrors.push("Vul uw geboortedatum in.");
    if (dateOfBirth) {
      const parsedDate = parseDutchDate(dateOfBirth);
      if (!parsedDate) {
        nextErrors.push("Vul een geldige geboortedatum in als dd-mm-jjjj.");
      } else if (parsedDate < "1900-01-01") {
        nextErrors.push("De geboortedatum moet in of na 1900 liggen.");
      } else if (parsedDate > todayAsIso()) {
        nextErrors.push("De geboortedatum kan niet in de toekomst liggen.");
      }
    }
    setErrors(nextErrors);
    return nextErrors.length === 0;
  }

  function next() {
    if (step === 0 && !validateIdentity()) return;
    if (currentQuestion && answers[currentQuestion.id] === undefined) {
      setErrors(["Kies een antwoord om verder te gaan."]);
      return;
    }
    setErrors([]);
    setStep((current) => Math.min(current + 1, totalSteps - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function finish() {
    if (!result) return;
    setCompleted({ ...result, completedAt: new Date().toISOString() });
    setErrors([]);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function makeFiles(activeResult: QuestionnaireResult) {
    const base = `${slug(activeResult.questionnaire.title) || "vragenlijst"}-${new Date()
      .toISOString()
      .slice(0, 10)}`;
    const pdfBlob = createPdfBlob(activeResult);
    const jsonBlob = new Blob([JSON.stringify(activeResult, null, 2)], {
      type: "application/json",
    });
    return {
      pdfBlob,
      jsonBlob,
      pdfFile: new File([pdfBlob], `${base}.pdf`, { type: "application/pdf" }),
      jsonFile: new File([jsonBlob], `${base}.json`, { type: "application/json" }),
    };
  }

  function mailBody(activeResult: QuestionnaireResult) {
    const lines = [
      "Beste zorgverlener,",
      "",
      `Naam: ${activeResult.patient.name}`,
      `Geboortedatum: ${formatDate(activeResult.patient.dateOfBirth)}`,
      `Vragenlijst: ${activeResult.questionnaire.title}`,
      `Versie: ${activeResult.questionnaire.version}`,
      `Totaalscore: ${activeResult.score.total} van ${activeResult.score.maximum}`,
      activeResult.score.interpretation
        ? `Duiding: ${activeResult.score.interpretation}`
        : "Duiding: niet ingesteld",
      "",
      "Antwoorden:",
      ...activeResult.responses.flatMap((response, index) => [
        `${index + 1}. ${response.question}`,
        `   ${response.answer} (${response.value})`,
      ]),
      "",
      "De PDF en JSON zijn lokaal op mijn apparaat gemaakt.",
    ];
    return lines.join("\n");
  }

  async function shareFiles() {
    if (!completed) return;
    const files = makeFiles(completed);
    const shareData = {
      title: `${completed.questionnaire.title} — ${completed.patient.name}`,
      text: mailBody(completed),
      files: [files.pdfFile, files.jsonFile],
    };
    try {
      if (navigator.share && navigator.canShare?.({ files: shareData.files })) {
        await navigator.share(shareData);
        setShareState("shared");
      } else {
        downloadBlob(files.pdfBlob, files.pdfFile.name);
        downloadBlob(files.jsonBlob, files.jsonFile.name);
        setShareState("downloaded");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      setShareState("error");
    }
  }

  function openMail() {
    if (!completed) return;
    const files = makeFiles(completed);
    downloadBlob(files.pdfBlob, files.pdfFile.name);
    downloadBlob(files.jsonBlob, files.jsonFile.name);
    const recipient = isValidEmail(definition.recipientEmail) ? definition.recipientEmail : "";
    const subject = encodeURIComponent(
      `${completed.questionnaire.title} — ${completed.patient.name}`,
    );
    const body = encodeURIComponent(mailBody(completed));
    window.location.href = `mailto:${encodeURIComponent(recipient)}?subject=${subject}&body=${body}`;
    setShareState("downloaded");
  }

  function openSecureRoute() {
    if (!completed) return;
    const files = makeFiles(completed);
    downloadBlob(files.pdfBlob, files.pdfFile.name);
    downloadBlob(files.jsonBlob, files.jsonFile.name);
    const target = safeHttpUrl(definition.secureUrl);
    if (target) window.open(target, "_blank", "noopener,noreferrer");
  }

  function reset() {
    setStep(0);
    setName("");
    setDateOfBirth("");
    setAnswers({});
    setCompleted(null);
    setShareState("idle");
    setErrors([]);
  }

  if (completed) {
    const secureTarget = safeHttpUrl(definition.secureUrl);
    return (
      <main className="app-shell">
        <Topbar />
        <div className="page-wrap result-wrap">
          <section className="result-hero" aria-labelledby="result-title">
            <div className="success-mark" aria-hidden="true">
              <Check />
            </div>
            <p className="eyebrow">Klaar om te delen</p>
            <h1 id="result-title">Uw antwoorden zijn overzichtelijk gemaakt</h1>
            <p>
              Er is niets naar deze website verstuurd. Kies hieronder zelf waar u de PDF en JSON
              naartoe stuurt.
            </p>
          </section>

          <div className="result-grid">
            <section className="score-card" aria-label="Uw score">
              <div className="score-ring">
                <strong>{completed.score.total}</strong>
                <span>van {completed.score.maximum}</span>
              </div>
              <div>
                <p className="eyebrow">Totaalscore</p>
                <h2>{completed.questionnaire.title}</h2>
                {completed.score.interpretation && (
                  <p className="interpretation-label">{completed.score.interpretation}</p>
                )}
                <p>{completed.score.advice ?? "Bespreek de uitslag zo nodig met uw zorgverlener."}</p>
                <small>De ESS is geen zelfstandige diagnostische test.</small>
              </div>
            </section>

            <section className="identity-card">
              <p>
                <span>Naam</span>
                <strong>{completed.patient.name}</strong>
              </p>
              <p>
                <span>Geboortedatum</span>
                <strong>{formatDate(completed.patient.dateOfBirth)}</strong>
              </p>
              <p>
                <span>Versie</span>
                <strong>{completed.questionnaire.version}</strong>
              </p>
            </section>
          </div>

          <Alert className="security-alert">
            <ShieldCheck aria-hidden="true" />
            <AlertTitle>Gebruik bij medische gegevens bij voorkeur de veilige route</AlertTitle>
            <AlertDescription>
              Gewone e-mail is niet automatisch veilig. Een portaal of een ingerichte ZODOS-route
              is geschikter voor gevoelige gegevens.
            </AlertDescription>
          </Alert>

          <section className="action-grid" aria-label="Deelopties">
            {secureTarget && (
              <article className="action-card preferred">
                <span className="preferred-label">Voorkeur</span>
                <LockKeyhole aria-hidden="true" />
                <h2>Veilige omgeving</h2>
                <p>
                  Download beide bestanden en ga daarna naar de ingestelde beveiligde omgeving.
                </p>
                <Button size="lg" onClick={openSecureRoute}>
                  Download en open veilig <ExternalLink aria-hidden="true" />
                </Button>
              </article>
            )}

            <article className="action-card">
              <Sparkles aria-hidden="true" />
              <h2>Deel PDF + JSON</h2>
              <p>
                Op geschikte telefoons en tablets opent dit het deelmenu met beide bestanden als
                bijlage.
              </p>
              <Button size="lg" variant="outline" onClick={shareFiles}>
                Kies een deel-app <ArrowRight aria-hidden="true" />
              </Button>
            </article>

            <article className="action-card">
              <Mail aria-hidden="true" />
              <h2>E-mail naar Mediwebs</h2>
              <p>
                Het mailconcept opent voor <strong>{definition.recipientEmail}</strong> en bevat
                alle antwoorden. Voeg de gedownloade bestanden zelf toe als uw mailprogramma dat
                niet automatisch doet.
              </p>
              <Button size="lg" variant="outline" onClick={openMail}>
                Download en open e-mail <Mail aria-hidden="true" />
              </Button>
            </article>
          </section>

          {shareState === "downloaded" && (
            <p className="status-message" role="status">
              PDF en JSON zijn gedownload. Voeg ze zelf toe als uw app ze niet automatisch als
              bijlage toont.
            </p>
          )}
          {shareState === "shared" && (
            <p className="status-message" role="status">Het deelmenu is geopend.</p>
          )}
          {shareState === "error" && (
            <p className="error-message" role="alert">
              Delen lukte niet. Probeer de e-mailroute of download opnieuw.
            </p>
          )}

          <details className="download-details">
            <summary>Hoe werkt downloaden en e-mailen?</summary>
            <div>
              <p>
                De PDF en JSON worden pas na uw klik lokaal op dit apparaat gemaakt en in de
                downloadmap gezet. Er wordt niets automatisch door deze website verstuurd.
              </p>
              <p>
                Daarna opent een mailconcept aan <strong>{definition.recipientEmail}</strong> met
                naam, geboortedatum, score en alle antwoorden in de tekst. Controleer de mail,
                voeg zo nodig de twee downloads als bijlage toe en druk zelf op verzenden.
              </p>
            </div>
          </details>

          <details className="answer-details">
            <summary>Bekijk alle antwoorden</summary>
            <ol>
              {completed.responses.map((response) => (
                <li key={response.questionId}>
                  <strong>{response.question}</strong>
                  <span>
                    {response.answer} ({response.value})
                  </span>
                </li>
              ))}
            </ol>
          </details>

          <div className="file-row" aria-label="Bestandsformaten">
            <span>
              <FileText aria-hidden="true" /> Leesbare PDF
            </span>
            <span>
              <FileJson aria-hidden="true" /> Verwerkbare JSON
            </span>
            <span>
              <ShieldCheck aria-hidden="true" /> Lokaal gemaakt
            </span>
          </div>

          <Button variant="ghost" className="reset-button" onClick={reset}>
            <RotateCcw aria-hidden="true" /> Wis gegevens en begin opnieuw
          </Button>
        </div>
        <SiteFooter definition={definition} />
      </main>
    );
  }

  return (
    <main className="app-shell">
      <Topbar />
      <div className="page-wrap form-wrap">
        {definitionError && (
          <Alert variant="destructive">
            <AlertTitle>Deze vragenlijstlink is beschadigd</AlertTitle>
            <AlertDescription>Daarom tonen we de veilige standaarddemo.</AlertDescription>
          </Alert>
        )}

        {definition.demoOnly && (
          <div className="demo-banner" role="note">
            <span>DEMO</span>
            Gebruik alleen fictieve gegevens — voor deze test wordt een geldige ESS-licentie verondersteld.
          </div>
        )}

        <p className="intake-nav"><Link href="/algemene-intake">Algemene medische intake</Link> · <Link href="/voorbeelden">Invullinks voor Inforium</Link></p>
        <header className="form-heading">
          <div>
            <p className="eyebrow">{definition.organization}</p>
            <h1>{definition.title}</h1>
            <p>{definition.description}</p>
          </div>
          <div className="local-badge">
            <LockKeyhole aria-hidden="true" /> Niets wordt online opgeslagen
          </div>
        </header>

        <div className="progress-block">
          <div>
            <span>{completed ? "Afgerond" : `Stap ${step + 1} van ${totalSteps}`}</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} aria-label={`Voortgang ${progress} procent`} />
        </div>

        <section className="question-card" aria-labelledby="step-title">
          {errors.length > 0 && (
            <div className="error-summary" role="alert" tabIndex={-1}>
              <strong>Controleer uw antwoord</strong>
              <ul>
                {errors.map((error) => (
                  <li key={error}>{error}</li>
                ))}
              </ul>
            </div>
          )}

          {step === 0 && (
            <div className="step-content">
              <div className="step-number">01</div>
              <h2 id="step-title">Wie vult de vragenlijst in?</h2>
              <p className="step-intro">
                Vul eerst uw naam en geboortedatum in. Deze gegevens blijven tijdens het invullen
                alleen in dit browservenster.
              </p>
              <div className="identity-grid">
                <div className="field-group">
                  <Label htmlFor="patient-name">Naam</Label>
                  <Input
                    id="patient-name"
                    name="patient-name"
                    autoComplete="name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Voornaam en achternaam"
                    aria-required="true"
                  />
                </div>
                <div className="field-group">
                  <Label htmlFor="date-of-birth">Geboortedatum</Label>
                  <Input
                    id="date-of-birth"
                    name="date-of-birth"
                    type="text"
                    inputMode="numeric"
                    autoComplete="bday"
                    placeholder="dd-mm-jjjj"
                    maxLength={10}
                    value={dateOfBirth}
                    onChange={(event) => setDateOfBirth(formatDateInput(event.target.value))}
                    aria-describedby="date-of-birth-help"
                    aria-required="true"
                  />
                  <small id="date-of-birth-help">Bijvoorbeeld: 07-04-1968</small>
                </div>
              </div>
              <div className="privacy-strip">
                <ShieldCheck aria-hidden="true" />
                <span>
                  <strong>Privacy by design:</strong> geen account, geen formulierverzending, geen
                  lokale opslag en geen tracking in deze demo.
                </span>
              </div>
              <p className="questionnaire-instruction">
                <strong>Zo vult u de vragenlijst in:</strong> {definition.instructions}
              </p>
            </div>
          )}

          {currentQuestion && (
            <div className="step-content">
              <div className="step-number">{String(step + 1).padStart(2, "0")}</div>
              <p className="question-kicker">
                Vraag {step} van {definition.questions.length}
              </p>
              <h2 id="step-title">{currentQuestion.text}</h2>
              {currentQuestion.help && <p className="step-intro">{currentQuestion.help}</p>}
              <RadioGroup
                className="answer-grid"
                value={answers[currentQuestion.id]?.toString()}
                onValueChange={(value) => {
                  setAnswers((current) => ({
                    ...current,
                    [currentQuestion.id]: Number(value),
                  }));
                  setErrors([]);
                }}
                aria-label={`Antwoord op ${currentQuestion.text}`}
              >
                {definition.answerOptions.map((option) => {
                  const optionId = `${currentQuestion.id}-${option.value}`;
                  return (
                    <Label className="answer-option" htmlFor={optionId} key={option.value}>
                      <RadioGroupItem id={optionId} value={option.value.toString()} />
                      <span className="answer-value">{option.value}</span>
                      <span>{option.label}</span>
                    </Label>
                  );
                })}
              </RadioGroup>
            </div>
          )}

          {isReview && result && (
            <div className="step-content review-content">
              <div className="step-number">
                <Check />
              </div>
              <p className="question-kicker">Controle</p>
              <h2 id="step-title">Klopt alles?</h2>
              <p className="step-intro">
                Bekijk uw gegevens en antwoorden voordat u lokaal de PDF en JSON maakt.
              </p>
              <div className="review-identity">
                <p>
                  <span>Naam</span>
                  <strong>{name}</strong>
                </p>
                <p>
                  <span>Geboortedatum</span>
                  <strong>{formatDate(dateOfBirth)}</strong>
                </p>
                <p>
                  <span>Beantwoord</span>
                  <strong>{definition.questions.length} van {definition.questions.length}</strong>
                </p>
              </div>
              <ol className="review-list">
                {result.responses.map((response, index) => (
                  <li key={response.questionId}>
                    <button type="button" onClick={() => setStep(index + 1)}>
                      <span>
                        {index + 1}. {response.question}
                      </span>
                      <strong>
                        {response.answer} ({response.value})
                      </strong>
                    </button>
                  </li>
                ))}
              </ol>
              <Alert className="license-alert">
                <AlertTitle>Bron en gebruiksrecht</AlertTitle>
                <AlertDescription>{definition.rightsNotice}</AlertDescription>
              </Alert>
            </div>
          )}

          <div className="form-actions">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setStep((current) => Math.max(0, current - 1))}
              disabled={step === 0}
            >
              <ArrowLeft aria-hidden="true" /> Vorige
            </Button>
            {isReview ? (
              <Button type="button" size="lg" onClick={finish}>
                Maak resultaat <Check aria-hidden="true" />
              </Button>
            ) : (
              <Button type="button" size="lg" onClick={next}>
                Volgende <ArrowRight aria-hidden="true" />
              </Button>
            )}
          </div>
        </section>

        <p className="support-note">
          Problemen met invullen? Neem contact op met uw zorgorganisatie. Deel hier geen medische
          gegevens.
        </p>
      </div>
      <SiteFooter definition={definition} />
    </main>
  );
}

function Topbar() {
  return (
    <nav className="topbar" aria-label="Hoofdnavigatie">
      <Link className="brand" href="/invullen/epworth">
        <span className="brand-mark" aria-hidden="true">
          <span />
        </span>
        <span>
          Inforium <strong>Vragenlijst</strong>
        </span>
      </Link>
      <Link className="maker-link" href="/maken">
        Maak een vragenlijst <ArrowRight aria-hidden="true" />
      </Link>
    </nav>
  );
}

function SiteFooter({ definition }: { definition: QuestionnaireDefinition }) {
  const sourceTarget = safeHttpUrl(definition.sourceUrl);
  return (
    <footer className="site-footer">
      <div>
        <strong>Over deze demo</strong>
        <p>
          De formulierinhoud staat in de link. Antwoorden, naam en geboortedatum worden niet naar
          de website verzonden.
        </p>
      </div>
      <div className="footer-links">
        {sourceTarget && (
          <a href={sourceTarget} target="_blank" rel="noreferrer">
            Bron en licentie <ExternalLink />
          </a>
        )}
        <a
          href="https://www.autoriteitpersoonsgegevens.nl/themas/gezondheid/gezondheidsgegevens-gebruiken-en-delen/gezondheidsgegevens-beveiligen"
          target="_blank"
          rel="noreferrer"
        >
          Privacy in de zorg <ExternalLink />
        </a>
      </div>
    </footer>
  );
}
