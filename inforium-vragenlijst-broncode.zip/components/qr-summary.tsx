"use client";
import {useState} from 'react';
import {QrCode,Download} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Textarea} from '@/components/ui/textarea';
import {makeQrSummary,qrByteLength,validateQrSummary,QR_SUMMARY_MAX_BYTES,type SummaryResponse} from '@/lib/qr-summary';

export default function QrSummary({title,questionnaireCode="INF-KORT-001",responses}:{title:string;questionnaireCode?:string;responses:SummaryResponse[]}){
 const [open,setOpen]=useState(false);
 const [selected,setSelected]=useState(responses.map(r=>r.questionId));
 const [text,setText]=useState(()=>makeQrSummary(questionnaireCode,responses,responses.map(r=>r.questionId)));
 const [image,setImage]=useState('');
 const [error,setError]=useState('');
 const [busy,setBusy]=useState(false);
 const validation=validateQrSummary(text);
 function changeText(value:string){setText(value);setImage('');setError('');}
 function toggle(id:string){const next=selected.includes(id)?selected.filter(x=>x!==id):[...selected,id];setSelected(next);changeText(makeQrSummary(questionnaireCode,responses,next));}
 async function generate(){
  if(validation){setError(validation);return;}
  setBusy(true);setError('');
  try{const {default:QRCode}=await import('qrcode');setImage(await QRCode.toDataURL([{data:new TextEncoder().encode(text),mode:'byte'}],{errorCorrectionLevel:'M',margin:4,width:800,color:{dark:'#000000',light:'#ffffff'}}));}
  catch{setError('De QR-code kon niet worden gemaakt. Probeer het opnieuw of download de PDF.');}
  finally{setBusy(false);}
 }
 return <section className="qr-summary">
  <Button variant="outline" aria-expanded={open} aria-controls="qr-summary-panel" onClick={()=>setOpen(!open)}><QrCode/>Maak QR van korte samenvatting</Button>
  {open&&<div id="qr-summary-panel" className="qr-summary-panel">
   <h2>QR van korte samenvatting</h2><p>Vragenlijst {questionnaireCode}: {title}. De QR bevat alleen het vragenlijstcode, vraagnummers en antwoorden. De volledige vraagteksten staan in de PDF en afdruk.</p>
   <p>Deze QR bevat de tekst zelf. Iedereen die de code scant kan die lezen. De code wordt op uw apparaat gemaakt, zonder online opslag. Gebruik in deze demo fictieve gegevens.</p>
   <fieldset><legend>Welke antwoorden wilt u opnemen?</legend>{responses.map(r=><label key={r.questionId} className="qr-choice"><input type="checkbox" checked={selected.includes(r.questionId)} disabled={busy} onChange={()=>toggle(r.questionId)}/>{r.questionNumber??responses.indexOf(r)+1}. {r.question}</label>)}</fieldset>
   <label htmlFor="qr-summary-text">Tekst in de QR-code (u kunt deze inkorten)</label>
   <Textarea id="qr-summary-text" rows={7} value={text} disabled={busy} onChange={e=>changeText(e.target.value)} aria-describedby="qr-summary-length"/>
   <p id="qr-summary-length" role="status">{qrByteLength(text)} / {QR_SUMMARY_MAX_BYTES} bytes. Dit is meestal ongeveer 800 gewone letters, inclusief de nummers en antwoorden. Accenten en emoji gebruiken meer bytes.</p>
   {validation&&<p className="error-message" role="alert">{validation}</p>}
   <Button disabled={busy||!!validation} onClick={generate}>{busy?'QR wordt gemaakt…':'Maak QR-code'}</Button>
   {error&&<p className="error-message" role="alert">{error}</p>}
   {image&&<div className="qr-output"><img src={image} width={800} height={800} alt="QR-code met de hierboven getoonde korte samenvatting"/><p>Scan met een QR-lezer die tekst ondersteunt. Hoe korter de tekst, hoe makkelijker de code te scannen is.</p><a className="qr-download" href={image} download="inforium-korte-samenvatting-qr.png"><Download size={18}/>Download QR als PNG</a></div>}
  </div>}
 </section>;
}
