import type {SummaryResponse} from '@/lib/qr-summary';
export default function PrintSummary({responses,completedAt,title,code}:{responses:SummaryResponse[];completedAt:string;title?:string;code?:string}){
 return <section className="print-answer-summary">{title&&<h1>{title}</h1>}{code&&<p>{code}</p>}<h2>Uw antwoorden / Your answers</h2><p>{new Date(completedAt).toLocaleString('nl-NL')}</p>{responses.map(r=><div className="print-answer" key={r.questionId}><h3>{r.questionNumber?`${r.questionNumber}. `:""}{r.question}</h3><p>{r.answer??'Niet ingevuld / Not answered'}</p></div>)}</section>;
}
